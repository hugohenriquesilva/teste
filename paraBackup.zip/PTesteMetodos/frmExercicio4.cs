﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }
        
        private void btnContNum_Click(object sender, EventArgs e)
        {
            string textao = richTxtFrase.Text;
            int contNumber = 0; 
            int tamanho = textao.Length;
            int contador = 0;
            while (tamanho > contador) 
            {
                if (char.IsNumber(textao[tamanho]) == true)
                {
                    contNumber += 1;
                }
                else
                { 
                }
                tamanho += 1;
            }
            MessageBox.Show("A quantidade de números no texto ao lado é de:" + contNumber);
            

        }


        /*
        private void button1_Click(object sender, EventArgs e)
        {

        }
        */


    }

}
