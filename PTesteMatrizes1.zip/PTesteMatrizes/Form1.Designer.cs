﻿namespace PTesteMatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExercicioUm = new System.Windows.Forms.Button();
            this.btnExercicioQuatro = new System.Windows.Forms.Button();
            this.btnExerciciotres = new System.Windows.Forms.Button();
            this.btnExerciciodois = new System.Windows.Forms.Button();
            this.btnExercicioCinco = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnExercicioUm
            // 
            this.btnExercicioUm.Location = new System.Drawing.Point(64, 56);
            this.btnExercicioUm.Name = "btnExercicioUm";
            this.btnExercicioUm.Size = new System.Drawing.Size(118, 23);
            this.btnExercicioUm.TabIndex = 0;
            this.btnExercicioUm.Text = "Exercício 1";
            this.btnExercicioUm.UseVisualStyleBackColor = true;
            this.btnExercicioUm.Click += new System.EventHandler(this.btnExercicioUm_Click);
            // 
            // btnExercicioQuatro
            // 
            this.btnExercicioQuatro.Location = new System.Drawing.Point(64, 224);
            this.btnExercicioQuatro.Name = "btnExercicioQuatro";
            this.btnExercicioQuatro.Size = new System.Drawing.Size(118, 23);
            this.btnExercicioQuatro.TabIndex = 1;
            this.btnExercicioQuatro.Text = "Exercício 4";
            this.btnExercicioQuatro.UseVisualStyleBackColor = true;
            // 
            // btnExerciciotres
            // 
            this.btnExerciciotres.Location = new System.Drawing.Point(64, 166);
            this.btnExerciciotres.Name = "btnExerciciotres";
            this.btnExerciciotres.Size = new System.Drawing.Size(118, 23);
            this.btnExerciciotres.TabIndex = 2;
            this.btnExerciciotres.Text = "Exercício 3";
            this.btnExerciciotres.UseVisualStyleBackColor = true;
            this.btnExerciciotres.Click += new System.EventHandler(this.btnExerciciotres_Click);
            // 
            // btnExerciciodois
            // 
            this.btnExerciciodois.Location = new System.Drawing.Point(64, 110);
            this.btnExerciciodois.Name = "btnExerciciodois";
            this.btnExerciciodois.Size = new System.Drawing.Size(118, 23);
            this.btnExerciciodois.TabIndex = 3;
            this.btnExerciciodois.Text = "Exercício 2";
            this.btnExerciciodois.UseVisualStyleBackColor = true;
            this.btnExerciciodois.Click += new System.EventHandler(this.btnExerciciodois_Click);
            // 
            // btnExercicioCinco
            // 
            this.btnExercicioCinco.Location = new System.Drawing.Point(64, 283);
            this.btnExercicioCinco.Name = "btnExercicioCinco";
            this.btnExercicioCinco.Size = new System.Drawing.Size(118, 23);
            this.btnExercicioCinco.TabIndex = 4;
            this.btnExercicioCinco.Text = "Exercício 5";
            this.btnExercicioCinco.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnExercicioCinco);
            this.Controls.Add(this.btnExerciciodois);
            this.Controls.Add(this.btnExerciciotres);
            this.Controls.Add(this.btnExercicioQuatro);
            this.Controls.Add(this.btnExercicioUm);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExercicioUm;
        private System.Windows.Forms.Button btnExercicioQuatro;
        private System.Windows.Forms.Button btnExerciciotres;
        private System.Windows.Forms.Button btnExerciciodois;
        private System.Windows.Forms.Button btnExercicioCinco;
    }
}

