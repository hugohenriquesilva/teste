﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic; //isso também serve para incluir o SQL server 


namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicioUm_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o { i + 1}°", "Entrada de dados");
                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Insira valor válido");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int x in vetor)
                auxiliar += x + "\n";

            MessageBox.Show(auxiliar);

        }

        private void btnExerciciodois_Click(object sender, EventArgs e)
        {
            ArrayList nome = new ArrayList()
            { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
            nome.Remove("Otávio");
            string auxiliar = "";

            foreach (string x in nome)
            {
                auxiliar += x + "\n";
            }
            MessageBox.Show($"Os nomes são: \n {auxiliar}");
        }

        private void btnExerciciotres_Click(object sender, EventArgs e)
        {
            double[,] nota = new double[20, 3];
            string auxiliar = ""; 

            for (int i = 0; i < 20; i++)
            {                             
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite as notas do aluno {i + 1}", $"coloque a nota {j+1}");
                    if (!int.TryParse()
                }
            }
        }
    }
}
